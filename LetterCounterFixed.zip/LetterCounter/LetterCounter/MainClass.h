#pragma once
class MainClass
{
public:
	MainClass();
	~MainClass();
};
